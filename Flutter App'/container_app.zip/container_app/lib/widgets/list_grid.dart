import 'package:flutter/material.dart';

class ListGrid extends StatefulWidget {
  const ListGrid({super.key});

  @override
  State<ListGrid> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<ListGrid> {
  final Map<String, String> fruitMap =  {
    "Orange": "Surya",
    "Grape": "Karan",
    "Mango": "Vikash",
    "Pineapple": "Hirthwik",
    "Apple": "Barathi",
    "Kiwi": "Akash",
    "Wine": "Kamal",
    "Lichie": "Vivek",
    "Choco": "Sugumar",
    "Hot Tea": "Sailesh",
    "Cold coffee": "Kumar",
    "Lemon Tea": "Vikranth",
    "Black coffee": "Vishal",
    "Badam": "Srini",
  };
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("List and Grid"),
        backgroundColor: Colors.amber,
        elevation: 10,
        shadowColor: Colors.blue,
      ),
      body: Container(
        padding: EdgeInsets.only(top: 10),
        color: Colors.brown,


        // Grid View


 child:(
  Card(
    child: GridView.builder(gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
    itemCount: fruitMap.length,
     itemBuilder: (context, index) {
      String fruit= fruitMap.keys.elementAt(index);
      String name= fruitMap.values.elementAt(index);

return Card(
child: GridTile(footer: Center(child: Text(index.toString(),style:  TextStyle(color: Colors.red))),
header: Text(name, style: TextStyle(color: Colors.pink),),child: Center(child: Text(fruit)),),

);
     } ,
     ) ,
  )
 
),






        // List view taken from an dictionary


        // child: ListView.builder(
        //   itemCount: fruitMap.length,
        //   itemBuilder: (context, index) {
        //     String fruit = fruitMap.keys.elementAt(index); // key
        //     String name = fruitMap.values.elementAt(index);
        //     return Card(
        //       child: ListTile(title: Text(fruit), subtitle: Text(name),
        //       leading: Icon(Icons.person_2_sharp),hoverColor: Colors.pink ,
        //       onTap: () => print("$fruit was eaten by $name"),),
              
        //     );
        //   }, 
        // ),






          // List view with the separate object added manually

          // children: [
          //   Card(
          //     surfaceTintColor: Colors.lightBlue,

          //     child: ListTile(
          //       title: Text("Orange"),
          //       subtitle: Text("Surya"),
          //     )
          //   ),
          //   Card(
          //     surfaceTintColor: Colors.lightBlue,
          //     child: ListTile(
          //       title: Text("Grape"),
          //       subtitle: Text("Karan"),
          //     )
          //   ),
          //   Card(
          //     surfaceTintColor: Colors.lightBlue,
          //     child: ListTile(
          //       title: Text("Mango"),
          //       subtitle: Text("Vikash"),
          //     )
          //   ),
          //   Card(
          //     surfaceTintColor: Colors.lightBlue,
          //     child: ListTile(
          //       title: Text("Pineapple"),
          //       subtitle: Text("Hirthwik"),
          //     )
          //   ),
          //   Card(
          //     surfaceTintColor: Colors.lightBlue,
          //     child: ListTile(
          //       title: Text("Apple"),
          //       subtitle: Text("Barathi"),
          //     )
          //   ),
          //   Card(
          //     surfaceTintColor: Colors.lightBlue,
          //     child: ListTile(
          //       title: Text("Kiwi"),
          //       subtitle: Text("Akash"),
          //     )
          //   ),
          //    Card(
          //     surfaceTintColor: Colors.lightBlue,
          //     child: ListTile(
          //       title: Text("Wine"),
          //       subtitle: Text("Kamal"),
          //     )
          //   ),
          //    Card(
          //     surfaceTintColor: Colors.lightBlue,
          //     child: ListTile(
          //       title: Text("Lichie"),
          //       subtitle: Text("Vivek"),
          //     )
          //   ),
          //    Card(
          //     surfaceTintColor: Colors.lightBlue,
          //     child: ListTile(
          //       title: Text("Choco"),
          //       subtitle: Text("Sugumar"),
          //     )
          //   ),
          //    Card(
          //     surfaceTintColor: Colors.lightBlue,
          //     child: ListTile(
          //       title: Text("Hot Tea"),
          //       subtitle: Text("Sailesh"),
          //     )
          //   ),
          //    Card(
          //     surfaceTintColor: Colors.lightBlue,
          //     child: ListTile(
          //       title: Text("Cold coffee"),
          //       subtitle: Text("Kumar"),

          //     )
          //   ),
          //    Card(
          //     surfaceTintColor: Colors.lightBlue,
          //     child: ListTile(
          //       title: Text("Lemon Tea"),
          //       subtitle: Text("Vikranth"),
          //     )
          //   ),
          //    Card(
          //     surfaceTintColor: Colors.lightBlue,
          //     child: ListTile(
          //       title: Text("Black coffe"),
          //       subtitle: Text("Vishal"),
          //     )
          //   ),
          //    Card(
          //     surfaceTintColor: Colors.lightBlue,
          //     child: ListTile(
          //       title: Text("Badam"),
          //       subtitle: Text("Srini"),
          //     )
          //   ),
          // ],
        // ),
      ),
    );
  }
}
