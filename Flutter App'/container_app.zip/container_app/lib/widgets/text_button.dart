import 'package:flutter/material.dart';

class ButtonWidget extends StatelessWidget {
  const ButtonWidget({super.key});

  @override
  Widget build(BuildContext context) {
    var h = MediaQuery.of(context).size.height;
    var w = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: Text("Button Widget"),
        backgroundColor: Colors.orange,
      ),
      body: Center(
        child: Container(
          height: h,
          width: w,
          color: Colors.blueGrey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,

            children: [
              TextButton(
                onPressed: () {},
                style: ButtonStyle(
                  padding: WidgetStateProperty.all(EdgeInsets.all(50)),

                  overlayColor: WidgetStateProperty.all(Colors.red),
                  backgroundColor: WidgetStateProperty.all(Colors.amber),
                ),
                child: Text("Press Me"),
              ),
              SizedBox(height: 20),
              SizedBox(
                height: 50,
                width: 300,
                child: ElevatedButton(
                  
                  style: ButtonStyle(
                    backgroundColor: WidgetStatePropertyAll(
                      Theme.of(context).primaryColor,
                    ),
                    elevation: WidgetStatePropertyAll(20)
                  ),
                  onPressed: () {
                    print("Like");
                  },
                  child: Text(
                    "Press Me",
                    style: TextStyle(color: Colors.white, fontSize: 22),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
