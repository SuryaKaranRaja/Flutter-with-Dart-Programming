import 'package:flutter/material.dart';

class RowsColumns extends StatelessWidget {
  const RowsColumns({super.key});

  @override
  Widget build(BuildContext context) {
    var h=MediaQuery.of(context).size.height;
     var w=MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Rows and Columns",
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.lightGreen,
     
      ),
      body: Container(
        height: h,
        width: w,
        color: Colors.yellowAccent,

        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [Row( crossAxisAlignment: CrossAxisAlignment.center,
            children: [ Container(margin: EdgeInsets.all(10),color:Colors.red, height :60, width: 60,),
          Container(margin: EdgeInsets.all(10),color:Colors.red, height :60, width: 60,),
          Container(margin: EdgeInsets.all(10),color:Colors.red, height :60, width: 60,),
          Container(margin: EdgeInsets.all(10),color:Colors.red, height :60, width: 60,),
          Container(margin: EdgeInsets.all(10),color:Colors.red, height :60, width: 60,)
          ],),
          
          Row(
             crossAxisAlignment: CrossAxisAlignment.center,
             children: [ Container(margin: EdgeInsets.all(10),color:Colors.orange, height :60, width: 60,),
          Container(margin: EdgeInsets.all(10),color:Colors.orange, height :60, width: 60,),
          Container(margin: EdgeInsets.all(10),color:Colors.orange, height :60, width: 60,),
          Container(margin: EdgeInsets.all(10),color:Colors.orange, height :60, width: 60,),
          Container(margin: EdgeInsets.all(10),color:Colors.orange, height :60, width: 60,)
          ],),
          
          
          
          ],),
        )

       

      ),
    );
  }
}
