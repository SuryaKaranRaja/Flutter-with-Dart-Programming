import 'package:flutter/material.dart';

class SnackBarWidget extends StatelessWidget {
  const SnackBarWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(

appBar: AppBar(
        title: Text("Snack Bar"),
        backgroundColor: Colors.green,
        elevation: 10,
        shadowColor: Colors.lightGreen,
      ),

      body: Container(
      child:Center(
        child: ElevatedButton(onPressed: (){
          final snackBar=SnackBar(content: Text("This is a Error"),
          backgroundColor: Colors.red,
          duration: const Duration(milliseconds: 7000),
          behavior: SnackBarBehavior.floating,
          action: SnackBarAction(label: "Undo", onPressed: (){
            ScaffoldMessenger.of(context).hideCurrentSnackBar();
          }, textColor: Colors.blue,),
          );
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        }, style: ButtonStyle(backgroundColor: WidgetStatePropertyAll(Colors.yellowAccent)), child: Text("Show Snack Bar"),)
      )
    ),
    );
  }
}