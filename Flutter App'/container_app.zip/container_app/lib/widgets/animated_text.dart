import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/material.dart';

class AnimatedText extends StatefulWidget {
  const AnimatedText({super.key});

  @override
  State<AnimatedText> createState() => _AnimatedTextState();
}

class _AnimatedTextState extends State<AnimatedText> {
  

  @override
  Widget build(BuildContext context) {
    var w=MediaQuery.of(context).size.width;
    var h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(title: const Text('Animated Text', style: TextStyle(color:Colors.white),),backgroundColor: const Color.fromARGB(255, 237, 161, 251),),
      body: Center(
        child: Container(
          color: const Color.fromARGB(255, 242, 222, 248),
         height: h,
         width: w,
          child: Row(
            
          
            children: [
              const SizedBox(width: 20,height: 100),
              SizedBox(
                width: 220,
                child: DefaultTextStyle(style: const TextStyle(fontSize: 40, fontFamily: 'Horizon', color: Colors.purple), 
                child: AnimatedTextKit(animatedTexts: [
                  RotateAnimatedText('Surya Karan'),
                  RotateAnimatedText("Hirthwik"),
                  
                ],totalRepeatCount: 100,
                  
                onTap: () => print("Tap Event"),)),
              ),
              const SizedBox(width: 20.0, height: 100.0),
              SizedBox(
                width: 110,
                child: const Text(
                        'Raja',
                        style: TextStyle(fontSize: 43.0),
                            ),
              ),
            ],
            
          ),
        ),
      ),
    );
  }
}
