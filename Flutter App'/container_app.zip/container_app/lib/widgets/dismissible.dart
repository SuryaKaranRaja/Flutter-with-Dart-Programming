import 'package:flutter/material.dart';

class DismissibleWidget extends StatefulWidget {
  const DismissibleWidget({super.key});

  @override
  State<DismissibleWidget> createState() => _DismissibleWidgetState();
}

class _DismissibleWidgetState extends State<DismissibleWidget> {
  List<String> cities = ["Madurai", "Chennai", "Salem", "kovai", "Trichy"];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Dismissible Packages"),
        backgroundColor: Colors.green,
        elevation: 10,
        shadowColor: Colors.lightGreen,
      ),
      body: ListView.builder(
        itemCount: cities.length,
        itemBuilder: (context, index) {
          final city = cities[index];
          return Dismissible(
            background: Container(color: Colors.red),
            secondaryBackground: Container(color: Colors.green),
            onDismissed: (direction) {
              if (direction == DismissDirection.startToEnd) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(cities[index]),
                    backgroundColor: Colors.lightGreen,
                  ),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(cities[index]),
                    backgroundColor: Colors.orange,
                  ),
                );
              }
            },
            key: Key(city),
            child: Card(child: ListTile(title: Text(cities[index]))),
          );
        },
      ),
    );
  }
}
