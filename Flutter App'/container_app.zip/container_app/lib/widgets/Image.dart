import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

class ImageWidget extends StatefulWidget {
  const ImageWidget({super.key});

  @override
  State<ImageWidget> createState() => _ImageWidthState();
}

class _ImageWidthState extends State<ImageWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Ben 10"),
        backgroundColor: Colors.amber,
        elevation: 10,
        shadowColor: Colors.blue,
      ),

      body: Center(

        // Network Image


        // child: Container(
        //   height: 300,
        //   width: 250,
         
        //   decoration: BoxDecoration(
        //     boxShadow: [BoxShadow(
        //       blurRadius: 20,
        //       color: Colors.pink
        //     )],
        //     image: DecorationImage(
        //       image: NetworkImage(
        //         'https://th.bing.com/th/id/OIP.kT8lfqscntMsuAv_uihepgHaK5?w=116&h=180&c=7&r=0&o=7&dpr=1.5&pid=1.7&rm=3',
        //       ),
        //       fit: BoxFit.cover,
        //     ),
        //     color: Colors.red,
        //     borderRadius: BorderRadius.circular(20),
        //   ),
        // ),


        // Assets Image

        // child: Container(
        //   height: 300,
        //   width: 400,
         
        //   decoration: BoxDecoration(
        //     boxShadow: [BoxShadow(
        //       blurRadius: 20,
        //       color: Colors.pink
        //     )],
        //     image: DecorationImage(
        //       image: AssetImage(
        //         'assets/cartoon10.jpeg',
        //       ),
        //       fit: BoxFit.cover,
        //     ),
        //     color: Colors.red,
        //     borderRadius: BorderRadius.circular(20),
        //   ),
        // ),



        //Cached image

         child: SizedBox(
          height: 300,
          width: 400,
         child: CachedNetworkImage(imageUrl: 'https://th.bing.com/th/id/OIP.Kdc60kMz2h73gtU--VL2ewHaEK?w=314&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7',
         placeholder: (context, url) => Center(child: CircularProgressIndicator()),
         errorWidget: (context, url, error) => Icon(Icons.error),) ,
        ),
      ),
    );
  }
}
