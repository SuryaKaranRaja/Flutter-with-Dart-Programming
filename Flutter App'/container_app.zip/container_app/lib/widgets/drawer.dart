import 'package:flutter/material.dart';

class DrawerWidget extends StatelessWidget {
  const DrawerWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: Container(
          color: Theme.of(context).primaryColor,
          child: ListTileTheme(
            iconColor: Colors.white,
            textColor: Colors.white,
            child: ListView(
              children: [
                DrawerHeader(
                  padding: EdgeInsetsGeometry.zero,
                  child: Container(
                    padding: EdgeInsets.all(5),
                    color: Colors.purpleAccent,
                    child: Row(children: [
                      CircleAvatar(radius: 40,
                      backgroundImage: NetworkImage('https://th.bing.com/th/id/OIP.ek78saq38Topa-OgllYs3gAAAA?w=179&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7'),),
                      SizedBox(width: 10),
Column(mainAxisAlignment: MainAxisAlignment.center,crossAxisAlignment: CrossAxisAlignment.start,children: [
  Text("I am Tom", style: TextStyle(color: Colors.white, fontSize: 22),),
  Text("A cat from Cartoon", style: TextStyle(color: Colors.white, fontSize: 18),)
],)
                    ]),
                  ),
                ),
                ListTile(leading: Icon(Icons.folder), title: Text("My file")),
                ListTile(
                  leading: Icon(Icons.group),
                  title: Text("Shared with me"),
                ),
                ListTile(leading: Icon(Icons.star), title: Text("Starred")),
                ListTile(leading: Icon(Icons.delete), title: Text("Trash")),
                ListTile(leading: Icon(Icons.upload), title: Text("Upload")),
                ListTile(leading: Icon(Icons.search), title: Text("Search")),
                ListTile(leading: Icon(Icons.edit), title: Text("Edit Files")),
                Divider( indent: 10, endIndent: 10, thickness: 2,),
                ListTile(leading: Icon(Icons.share), title: Text("Share")),
                ListTile(leading: Icon(Icons.logout), title: Text("Log out"))
              ],
            ),
          ),
        ),
      ),
      appBar: AppBar(
        title: Text("Drawer Widget"),
        backgroundColor: Colors.amber,
        elevation: 10,
        shadowColor: Colors.blue,
      ),
      body: Container(child: Center(child: Text("Hai there"))),
    );
  }
}
