import 'package:flutter/material.dart';

class AlertWidget extends StatefulWidget {
  const AlertWidget({super.key});

  @override
  State<AlertWidget> createState() => _AlertWidgetState();
}

class _AlertWidgetState extends State<AlertWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Alert",
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.deepPurple,

        bottom: AppBar(backgroundColor: Colors.amberAccent),
      ),

      body: Center(
        child: ElevatedButton(
          style: ButtonStyle(
            backgroundColor: WidgetStatePropertyAll(Colors.pink),
          ),
          onPressed: () {
            _showMyDialog(context);
          },
          child: Text("Show Alert", style: TextStyle(color: Colors.white)),
        ),
      ),
    );
  }
}


Future<void> _showMyDialog(BuildContext context)async
{
  return showDialog(context: context, builder: (BuildContext context)
  {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadiusGeometry.circular(20)),
      title: Text("This is my Alert Page"),
      content: SingleChildScrollView(
        child: ListBody(
          children: [
            Text("Welcome to ALert"),
            Text("How can I help U"),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: (){}, child: Text("Approved")),
        TextButton(onPressed: (){
          Navigator.of(context).pop();
        }, child: Text("Cancel")),
      ],
    );
  });
}