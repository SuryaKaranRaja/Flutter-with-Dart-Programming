import 'package:flutter/material.dart';

class BoyttomSheetWidget extends StatelessWidget {
  const BoyttomSheetWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Bottom Sheet"),
        backgroundColor: Colors.amber,
        elevation: 10,
        shadowColor: Colors.blue,
      ),

      body: Center(
        child: ElevatedButton(
          style: ButtonStyle(
            backgroundColor: WidgetStatePropertyAll(Colors.pink),
          ),
          onPressed: () {
            showModalBottomSheet(
              isDismissible: false,
              isScrollControlled: true,
              context: context,
              builder: (context) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ListTile(
                      title: Text("Front End"),
                      subtitle: Text("HTML, CSS"),
                    ),
                    ListTile(
                      title: Text("Back End"),
                      subtitle: Text("JavaScript"),
                    ),
                    ListTile(
                      title: Text("Data base"),
                      subtitle: Text("Mopngo DB"),
                    ),
                    ListTile(
                      title: Text("Mobile dev"),
                      subtitle: Text("Flutter"),
                    ),
                    ListTile(
                      title: Text("IOS native"),
                      subtitle: Text("Swift"),
                    ),
                  ],
                );
              },
            );
          },
          child: Text(
            "Show Bottom Sheet",
            style: TextStyle(color: Colors.white),
          ),
        ),
      ),
    );
  }
}
