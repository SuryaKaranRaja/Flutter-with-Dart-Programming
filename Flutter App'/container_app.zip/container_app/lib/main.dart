import 'package:container_app/widgets/animated_text.dart';
import 'package:flutter/material.dart';


void main() {
  runApp(const container_app());
}

class container_app extends StatelessWidget {
  const container_app({super.key});

  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.light, 
        primaryColor:  Colors.deepPurple
      ),
      home:AnimatedText()
    );
  }
}
