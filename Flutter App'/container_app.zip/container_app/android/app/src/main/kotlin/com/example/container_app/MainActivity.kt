package com.example.container_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
